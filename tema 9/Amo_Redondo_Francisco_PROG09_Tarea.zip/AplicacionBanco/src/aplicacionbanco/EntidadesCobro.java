
package aplicacionbanco;



public enum EntidadesCobro {
 CAIXA,
 SANTANDER,
 BANKIA,
 BBVA,
 OPENBANK;

    public static EntidadesCobro getCAIXA() {
        return CAIXA;
    }

    public static EntidadesCobro getSANTANDER() {
        return SANTANDER;
    }

    public static EntidadesCobro getBANKIA() {
        return BANKIA;
    }

    public static EntidadesCobro getBBVA() {
        return BBVA;
    }

    public static EntidadesCobro getOPENBANK() {
        return OPENBANK;
    }
 
 
 
 
}
